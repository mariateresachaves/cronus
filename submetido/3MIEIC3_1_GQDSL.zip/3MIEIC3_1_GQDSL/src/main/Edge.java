package main;

public class Edge {

}
